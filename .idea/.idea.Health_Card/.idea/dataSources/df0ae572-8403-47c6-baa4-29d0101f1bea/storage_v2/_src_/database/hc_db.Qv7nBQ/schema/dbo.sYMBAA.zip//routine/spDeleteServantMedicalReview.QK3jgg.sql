CREATE PROCEDURE spDeleteServantMedicalReview
@ReviewID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM ServantMedicalReviews
    WHERE ReviewID = @ReviewID;
END
go

