CREATE VIEW vwChronicDiseases AS
SELECT
    ChronicDiseaseID,
    ServantID,
    DiseaseName,
    Notes,
    DiseaseType,
    FamilyMemberRelation,
    CreatedAt
FROM ChronicDiseases
go

