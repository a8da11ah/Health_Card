CREATE PROCEDURE spGetServantChronicTreatmentById
@TreatmentID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        TreatmentID,
        ServantID,
        TreatmentName,
        Notes,
        CreatedAt
    FROM ServantChronicTreatments
    WHERE TreatmentID = @TreatmentID;
END
go

