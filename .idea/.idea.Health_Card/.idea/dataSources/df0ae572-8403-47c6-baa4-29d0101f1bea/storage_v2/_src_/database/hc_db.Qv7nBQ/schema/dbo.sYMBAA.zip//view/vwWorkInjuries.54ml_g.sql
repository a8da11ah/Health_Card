CREATE VIEW vwWorkInjuries AS
SELECT
    InjuryID,
    ServantID,
    InjuryDate,
    InjuryType,
    DepartmentOfInjury,
    Description,
    CreatedAt
FROM WorkInjuries
go

