CREATE PROCEDURE spUpdateServantChronicTreatment
    @TreatmentID INT,
    @ServantID INT,
    @TreatmentName NVARCHAR(255),
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ServantChronicTreatments
    SET
        ServantID = @ServantID,
        TreatmentName = @TreatmentName,
        Notes = @Notes
    WHERE TreatmentID = @TreatmentID;
END
go

