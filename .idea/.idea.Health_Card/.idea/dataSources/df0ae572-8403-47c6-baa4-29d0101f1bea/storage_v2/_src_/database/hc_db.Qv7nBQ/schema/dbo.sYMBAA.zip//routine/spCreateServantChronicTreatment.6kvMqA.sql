CREATE PROCEDURE spCreateServantChronicTreatment
    @ServantID INT,
    @TreatmentName NVARCHAR(255),
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ServantChronicTreatments
    (
        ServantID,
        TreatmentName,
        Notes,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @TreatmentName,
            @Notes,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS TreatmentID;
END
go

