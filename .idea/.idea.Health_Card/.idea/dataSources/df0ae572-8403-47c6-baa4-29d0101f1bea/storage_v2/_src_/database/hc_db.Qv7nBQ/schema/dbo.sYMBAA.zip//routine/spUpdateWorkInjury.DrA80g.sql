CREATE PROCEDURE spUpdateWorkInjury
    @InjuryID INT,
    @ServantID INT,
    @InjuryDate DATE,
    @InjuryType NVARCHAR(255),
    @DepartmentOfInjury NVARCHAR(255) = NULL,
    @Description NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE WorkInjuries
    SET
        ServantID = @ServantID,
        InjuryDate = @InjuryDate,
        InjuryType = @InjuryType,
        DepartmentOfInjury = @DepartmentOfInjury,
        Description = @Description
    WHERE InjuryID = @InjuryID;
END
go

