CREATE PROCEDURE spUpdateSurgicalOperation
    @OperationID INT,
    @ServantID INT,
    @OperationDate DATE,
    @OperationType NVARCHAR(255),
    @HospitalName NVARCHAR(255) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE SurgicalOperations
    SET
        ServantID = @ServantID,
        OperationDate = @OperationDate,
        OperationType = @OperationType,
        HospitalName = @HospitalName,
        Notes = @Notes
    WHERE OperationID = @OperationID;
END
go

