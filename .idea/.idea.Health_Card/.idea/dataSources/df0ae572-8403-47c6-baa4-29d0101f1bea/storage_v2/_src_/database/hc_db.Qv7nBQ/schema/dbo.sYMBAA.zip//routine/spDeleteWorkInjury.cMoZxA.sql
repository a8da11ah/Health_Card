CREATE PROCEDURE spDeleteWorkInjury
@InjuryID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM WorkInjuries
    WHERE InjuryID = @InjuryID;
END
go

