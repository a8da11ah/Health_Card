CREATE VIEW vwMedicalReferrals AS
SELECT
    ReferralID,
    ServantID,
    ReferralDate,
    MedicalDiagnosis,
    LeaveType,
    LeaveDays,
    CreatedAt
FROM MedicalReferrals
go

