CREATE PROCEDURE spCreateGeneralRemark
    @ServantID INT,
    @Remarks NVARCHAR(MAX) = NULL,
    @OtherNotes NVARCHAR(MAX) = NULL,
    @CreatedBy NVARCHAR(255) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO GeneralRemarks
    (
        ServantID,
        Remarks,
        OtherNotes,
        CreatedBy,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @Remarks,
            @OtherNotes,
            @CreatedBy,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS RemarkID;
END
go

