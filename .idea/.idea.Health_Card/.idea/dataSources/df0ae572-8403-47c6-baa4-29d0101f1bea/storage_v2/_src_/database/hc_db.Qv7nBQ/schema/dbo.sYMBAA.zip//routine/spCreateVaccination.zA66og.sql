CREATE PROCEDURE spCreateVaccination
    @ServantID INT,
    @VaccinationDate DATE,
    @VaccinationType NVARCHAR(255),
    @VaccinationLocation NVARCHAR(255) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Vaccinations
    (
        ServantID,
        VaccinationDate,
        VaccinationType,
        VaccinationLocation,
        Notes,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @VaccinationDate,
            @VaccinationType,
            @VaccinationLocation,
            @Notes,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS VaccinationID;
END
go

