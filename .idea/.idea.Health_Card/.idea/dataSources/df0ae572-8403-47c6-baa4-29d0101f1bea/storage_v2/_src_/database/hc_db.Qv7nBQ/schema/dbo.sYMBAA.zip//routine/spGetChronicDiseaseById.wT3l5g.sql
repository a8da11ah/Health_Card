CREATE PROCEDURE spGetChronicDiseaseById
@ChronicDiseaseID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ChronicDiseaseID,
        ServantID,
        DiseaseName,
        Notes,
        DiseaseType,
        FamilyMemberRelation,
        CreatedAt
    FROM ChronicDiseases
    WHERE ChronicDiseaseID = @ChronicDiseaseID;
END
go

