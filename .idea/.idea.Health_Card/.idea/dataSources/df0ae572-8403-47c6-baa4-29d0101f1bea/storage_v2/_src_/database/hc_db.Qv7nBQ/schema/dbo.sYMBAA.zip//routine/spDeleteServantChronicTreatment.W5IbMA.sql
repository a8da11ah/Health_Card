CREATE PROCEDURE spDeleteServantChronicTreatment
@TreatmentID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM ServantChronicTreatments
    WHERE TreatmentID = @TreatmentID;
END
go

