CREATE PROCEDURE spDeleteMedicalReferral
@ReferralID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM MedicalReferrals
    WHERE ReferralID = @ReferralID;
END
go

