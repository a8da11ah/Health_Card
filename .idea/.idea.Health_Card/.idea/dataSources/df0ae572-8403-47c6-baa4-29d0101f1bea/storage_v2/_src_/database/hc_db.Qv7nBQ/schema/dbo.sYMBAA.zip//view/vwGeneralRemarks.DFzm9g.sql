CREATE VIEW vwGeneralRemarks AS
SELECT
    RemarkID,
    ServantID,
    Remarks,
    OtherNotes,
    CreatedBy,
    CreatedAt
FROM GeneralRemarks
go

