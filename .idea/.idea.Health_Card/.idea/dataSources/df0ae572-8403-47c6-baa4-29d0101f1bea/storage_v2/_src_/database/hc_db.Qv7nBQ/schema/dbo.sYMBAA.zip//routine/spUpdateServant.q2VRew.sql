CREATE PROCEDURE spUpdateServant
    @ServantID INT,
    @BirthDate DATE = NULL,
    @Gender NVARCHAR(50) = NULL,
    @MaritalStatus NVARCHAR(50) = NULL,
    @BloodType NVARCHAR(10) = NULL,
    @Height DECIMAL(5,2) = NULL,
    @Weight DECIMAL(5,2) = NULL,
    @EducationalQualification NVARCHAR(255) = NULL,
    @SmokingStatus BIT,
    @DrugAllergies NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Servants
    SET
        BirthDate = @BirthDate,
        Gender = @Gender,
        MaritalStatus = @MaritalStatus,
        BloodType = @BloodType,
        Height = @Height,
        Weight = @Weight,
        EducationalQualification = @EducationalQualification,
        SmokingStatus = @SmokingStatus,
        DrugAllergies = @DrugAllergies,
        UpdatedAt = SYSUTCDATETIME()
    WHERE ServantID = @ServantID;
END
go

