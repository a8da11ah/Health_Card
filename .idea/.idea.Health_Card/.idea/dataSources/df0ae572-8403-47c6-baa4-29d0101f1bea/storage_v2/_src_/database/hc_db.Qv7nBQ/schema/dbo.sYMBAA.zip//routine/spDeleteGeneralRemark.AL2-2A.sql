CREATE PROCEDURE spDeleteGeneralRemark
@RemarkID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM GeneralRemarks
    WHERE RemarkID = @RemarkID;
END
go

