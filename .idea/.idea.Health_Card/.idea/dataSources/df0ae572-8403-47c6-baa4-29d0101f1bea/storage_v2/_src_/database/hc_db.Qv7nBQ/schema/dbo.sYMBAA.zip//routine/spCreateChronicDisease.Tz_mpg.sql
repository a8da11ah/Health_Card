CREATE PROCEDURE spCreateChronicDisease
    @ServantID INT,
    @DiseaseName NVARCHAR(255),
    @Notes NVARCHAR(MAX) = NULL,
    @DiseaseType INT = 0, -- default PERSONAL
    @FamilyMemberRelation NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ChronicDiseases
    (
        ServantID,
        DiseaseName,
        Notes,
        DiseaseType,
        FamilyMemberRelation,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @DiseaseName,
            @Notes,
            @DiseaseType,
            @FamilyMemberRelation,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS ChronicDiseaseID;
END
go

