CREATE PROCEDURE spCreateServantMedicalReview
    @ServantID INT,
    @ReviewDate DATE,
    @ReviewType NVARCHAR(100) = NULL,
    @MedicalDiagnosis NVARCHAR(MAX) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO ServantMedicalReviews
    (
        ServantID,
        ReviewDate,
        ReviewType,
        MedicalDiagnosis,
        Notes,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @ReviewDate,
            @ReviewType,
            @MedicalDiagnosis,
            @Notes,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS ReviewID;
END
go

