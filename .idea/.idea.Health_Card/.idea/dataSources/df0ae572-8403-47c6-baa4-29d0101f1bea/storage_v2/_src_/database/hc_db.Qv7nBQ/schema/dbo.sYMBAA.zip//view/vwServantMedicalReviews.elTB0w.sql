CREATE VIEW vwServantMedicalReviews AS
SELECT
    ReviewID,
    ServantID,
    ReviewDate,
    ReviewType,
    MedicalDiagnosis,
    Notes,
    CreatedAt
FROM ServantMedicalReviews
go

