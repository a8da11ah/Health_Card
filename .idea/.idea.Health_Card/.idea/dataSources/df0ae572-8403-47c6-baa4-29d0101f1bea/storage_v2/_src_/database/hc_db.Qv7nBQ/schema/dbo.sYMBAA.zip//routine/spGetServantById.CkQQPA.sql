CREATE PROCEDURE spGetServantById
@ServantID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ServantID,
        BirthDate,
        Gender,
        MaritalStatus,
        BloodType,
        Height,
        Weight,
        EducationalQualification,
        SmokingStatus,
        DrugAllergies,
        CreatedAt,
        UpdatedAt
    FROM Servants
    WHERE ServantID = @ServantID;
END
go

