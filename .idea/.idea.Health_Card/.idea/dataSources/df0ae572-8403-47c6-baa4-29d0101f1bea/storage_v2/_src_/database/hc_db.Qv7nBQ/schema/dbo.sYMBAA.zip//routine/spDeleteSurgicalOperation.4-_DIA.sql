CREATE PROCEDURE spDeleteSurgicalOperation
@OperationID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM SurgicalOperations
    WHERE OperationID = @OperationID;
END
go

