CREATE PROCEDURE spGetGeneralRemarkById
@RemarkID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        RemarkID,
        ServantID,
        Remarks,
        OtherNotes,
        CreatedBy,
        CreatedAt
    FROM GeneralRemarks
    WHERE RemarkID = @RemarkID;
END
go

