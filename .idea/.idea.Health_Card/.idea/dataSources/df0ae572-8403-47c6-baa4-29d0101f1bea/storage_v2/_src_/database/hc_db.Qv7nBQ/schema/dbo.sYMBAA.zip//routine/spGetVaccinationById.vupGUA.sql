CREATE PROCEDURE spGetVaccinationById
@VaccinationID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        VaccinationID,
        ServantID,
        VaccinationDate,
        VaccinationType,
        VaccinationLocation,
        Notes,
        CreatedAt
    FROM Vaccinations
    WHERE VaccinationID = @VaccinationID;
END
go

