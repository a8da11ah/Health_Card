CREATE PROCEDURE spCreateSurgicalOperation
    @ServantID INT,
    @OperationDate DATE,
    @OperationType NVARCHAR(255),
    @HospitalName NVARCHAR(255) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO SurgicalOperations
    (
        ServantID,
        OperationDate,
        OperationType,
        HospitalName,
        Notes,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @OperationDate,
            @OperationType,
            @HospitalName,
            @Notes,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS OperationID;
END
go

