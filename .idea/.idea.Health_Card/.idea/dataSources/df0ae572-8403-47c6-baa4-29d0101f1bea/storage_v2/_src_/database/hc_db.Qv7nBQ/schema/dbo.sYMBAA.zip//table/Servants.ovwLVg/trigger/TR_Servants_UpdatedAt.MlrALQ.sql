CREATE TRIGGER TR_Servants_UpdatedAt
    ON Servants
    AFTER UPDATE
    AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Servants
    SET UpdatedAt = GETDATE()
    FROM Servants s
             INNER JOIN inserted i ON s.ServantID = i.ServantID;
END;
go

