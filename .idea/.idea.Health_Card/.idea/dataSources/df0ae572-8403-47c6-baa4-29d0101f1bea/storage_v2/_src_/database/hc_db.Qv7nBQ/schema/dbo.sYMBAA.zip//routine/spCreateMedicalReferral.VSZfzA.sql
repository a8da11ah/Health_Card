CREATE PROCEDURE spCreateMedicalReferral
    @ServantID INT,
    @ReferralDate DATE, -- Assuming DATE type for date-only field
    @MedicalDiagnosis NVARCHAR(MAX), -- Assuming string without length means MAX
    @LeaveType NVARCHAR(255) = NULL,
    @LeaveDays INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO MedicalReferrals
    (
        ServantID,
        ReferralDate,
        MedicalDiagnosis,
        LeaveType,
        LeaveDays,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @ReferralDate,
            @MedicalDiagnosis,
            @LeaveType,
            @LeaveDays,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS ReferralID;
END
go

