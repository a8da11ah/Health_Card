CREATE PROCEDURE spGetSurgicalOperationById
@OperationID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        OperationID,
        ServantID,
        OperationDate,
        OperationType,
        HospitalName,
        Notes,
        CreatedAt
    FROM SurgicalOperations
    WHERE OperationID = @OperationID;
END
go

