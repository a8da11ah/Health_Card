CREATE PROCEDURE spDeleteChronicDisease
@ChronicDiseaseID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM ChronicDiseases
    WHERE ChronicDiseaseID = @ChronicDiseaseID;
END
go

