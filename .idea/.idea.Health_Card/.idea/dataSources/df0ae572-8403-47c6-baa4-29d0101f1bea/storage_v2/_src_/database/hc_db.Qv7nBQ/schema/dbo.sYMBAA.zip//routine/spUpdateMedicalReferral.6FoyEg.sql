CREATE PROCEDURE spUpdateMedicalReferral
    @ReferralID INT,
    @ServantID INT,
    @ReferralDate DATE,
    @MedicalDiagnosis NVARCHAR(MAX),
    @LeaveType NVARCHAR(255) = NULL,
    @LeaveDays INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE MedicalReferrals
    SET
        ServantID = @ServantID,
        ReferralDate = @ReferralDate,
        MedicalDiagnosis = @MedicalDiagnosis,
        LeaveType = @LeaveType,
        LeaveDays = @LeaveDays
    WHERE ReferralID = @ReferralID;
END
go

