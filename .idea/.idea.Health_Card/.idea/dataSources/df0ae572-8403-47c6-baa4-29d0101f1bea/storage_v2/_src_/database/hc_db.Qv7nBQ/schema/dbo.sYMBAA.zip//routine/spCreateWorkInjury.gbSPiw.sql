CREATE PROCEDURE spCreateWorkInjury
    @ServantID INT,
    @InjuryDate DATE,
    @InjuryType NVARCHAR(255),
    @DepartmentOfInjury NVARCHAR(255) = NULL,
    @Description NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO WorkInjuries
    (
        ServantID,
        InjuryDate,
        InjuryType,
        DepartmentOfInjury,
        Description,
        CreatedAt
    )
    VALUES
        (
            @ServantID,
            @InjuryDate,
            @InjuryType,
            @DepartmentOfInjury,
            @Description,
            SYSUTCDATETIME()
        );

    SELECT CAST(SCOPE_IDENTITY() AS INT) AS InjuryID;
END
go

