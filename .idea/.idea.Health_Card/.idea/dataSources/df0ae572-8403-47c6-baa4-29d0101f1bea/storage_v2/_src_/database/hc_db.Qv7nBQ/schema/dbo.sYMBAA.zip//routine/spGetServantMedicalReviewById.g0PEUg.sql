CREATE PROCEDURE spGetServantMedicalReviewById
@ReviewID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ReviewID,
        ServantID,
        ReviewDate,
        ReviewType,
        MedicalDiagnosis,
        Notes,
        CreatedAt
    FROM ServantMedicalReviews
    WHERE ReviewID = @ReviewID;
END
go

