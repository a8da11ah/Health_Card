CREATE VIEW vwVaccinations AS
SELECT
    VaccinationID,
    ServantID,
    VaccinationDate,
    VaccinationType,
    VaccinationLocation,
    Notes,
    CreatedAt
FROM Vaccinations
go

