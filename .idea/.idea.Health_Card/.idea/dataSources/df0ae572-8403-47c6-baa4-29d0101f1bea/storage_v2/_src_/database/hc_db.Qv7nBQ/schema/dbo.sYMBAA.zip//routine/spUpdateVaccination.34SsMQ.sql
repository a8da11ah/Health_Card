CREATE PROCEDURE spUpdateVaccination
    @VaccinationID INT,
    @ServantID INT,
    @VaccinationDate DATE,
    @VaccinationType NVARCHAR(255),
    @VaccinationLocation NVARCHAR(255) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE Vaccinations
    SET
        ServantID = @ServantID,
        VaccinationDate = @VaccinationDate,
        VaccinationType = @VaccinationType,
        VaccinationLocation = @VaccinationLocation,
        Notes = @Notes
    WHERE VaccinationID = @VaccinationID;
END
go

