CREATE PROCEDURE spDeleteVaccination
@VaccinationID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM Vaccinations
    WHERE VaccinationID = @VaccinationID;
END
go

