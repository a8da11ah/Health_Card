CREATE PROCEDURE spUpdateServantMedicalReview
    @ReviewID INT,
    @ServantID INT,
    @ReviewDate DATE,
    @ReviewType NVARCHAR(100) = NULL,
    @MedicalDiagnosis NVARCHAR(MAX) = NULL,
    @Notes NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ServantMedicalReviews
    SET
        ServantID = @ServantID,
        ReviewDate = @ReviewDate,
        ReviewType = @ReviewType,
        MedicalDiagnosis = @MedicalDiagnosis,
        Notes = @Notes
    WHERE ReviewID = @ReviewID;
END
go

