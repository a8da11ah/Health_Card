CREATE PROCEDURE spDeleteServant
@ServantID INT
AS
BEGIN
    SET NOCOUNT ON;

    DELETE FROM Servants WHERE ServantID = @ServantID;
END
go

