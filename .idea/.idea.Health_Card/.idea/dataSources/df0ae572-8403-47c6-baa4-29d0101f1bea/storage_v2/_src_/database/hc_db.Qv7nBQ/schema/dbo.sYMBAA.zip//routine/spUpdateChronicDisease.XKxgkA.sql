CREATE PROCEDURE spUpdateChronicDisease
    @ChronicDiseaseID INT,
    @ServantID INT,
    @DiseaseName NVARCHAR(255),
    @Notes NVARCHAR(MAX) = NULL,
    @DiseaseType INT,
    @FamilyMemberRelation NVARCHAR(100) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE ChronicDiseases
    SET
        ServantID = @ServantID,
        DiseaseName = @DiseaseName,
        Notes = @Notes,
        DiseaseType = @DiseaseType,
        FamilyMemberRelation = @FamilyMemberRelation
    WHERE ChronicDiseaseID = @ChronicDiseaseID;
END
go

