CREATE PROCEDURE spGetWorkInjuryById
@InjuryID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        InjuryID,
        ServantID,
        InjuryDate,
        InjuryType,
        DepartmentOfInjury,
        Description,
        CreatedAt
    FROM WorkInjuries
    WHERE InjuryID = @InjuryID;
END
go

