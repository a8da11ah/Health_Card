CREATE PROCEDURE spUpdateGeneralRemark
    @RemarkID INT,
    @ServantID INT,
    @Remarks NVARCHAR(MAX) = NULL,
    @OtherNotes NVARCHAR(MAX) = NULL,
    @CreatedBy NVARCHAR(255) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE GeneralRemarks
    SET
        ServantID = @ServantID,
        Remarks = @Remarks,
        OtherNotes = @OtherNotes,
        CreatedBy = @CreatedBy
    WHERE RemarkID = @RemarkID;
END
go

