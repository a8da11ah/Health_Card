CREATE VIEW vwSurgicalOperations AS
SELECT
    OperationID,
    ServantID,
    OperationDate,
    OperationType,
    HospitalName,
    Notes,
    CreatedAt
FROM SurgicalOperations
go

