CREATE VIEW vwServantChronicTreatments AS
SELECT
    TreatmentID,
    ServantID,
    TreatmentName,
    Notes,
    CreatedAt
FROM ServantChronicTreatments
go

