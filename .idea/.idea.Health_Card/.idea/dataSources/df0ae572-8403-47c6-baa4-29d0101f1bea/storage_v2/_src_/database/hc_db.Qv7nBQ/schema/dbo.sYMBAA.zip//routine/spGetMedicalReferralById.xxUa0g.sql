CREATE PROCEDURE spGetMedicalReferralById
@ReferralID INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        ReferralID,
        ServantID,
        ReferralDate,
        MedicalDiagnosis,
        LeaveType,
        LeaveDays,
        CreatedAt
    FROM MedicalReferrals
    WHERE ReferralID = @ReferralID;
END
go

